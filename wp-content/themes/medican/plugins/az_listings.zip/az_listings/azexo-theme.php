<?php

global $azl_templates;
$azl_templates = array(
    'google_map_product' => esc_html__('Google Map product', 'azl'),
);
add_filter('azexo_templates', 'azl_templates');

function azl_templates($azexo_templates) {
    global $azl_templates;
    return array_merge($azexo_templates, $azl_templates);
}

add_filter('azexo_post_template_path', 'azl_post_template_path', 10, 2);

function azl_post_template_path($template, $template_name) {
    global $azl_templates;
    if (in_array($template_name, array_keys($azl_templates))) {
        return array("content-product.php", WC()->template_path() . "content-product.php");
    } else {
        return $template;
    }
}

global $azl_fields;

$azl_fields = array(
    'azl_edit_link' => esc_html__('Listing: Edit link', 'azl'),
    'azl_delete_link' => esc_html__('Listing: Delete link', 'azl'),
    'azl_claim_link' => esc_html__('Listing: Claim link', 'azl'),
    'azl_abuse_link' => esc_html__('Listing: Abuse link', 'azl'),
    'azl_favorite_link' => esc_html__('Listing: Favorite link', 'azl'),
);

add_filter('azexo_fields', 'azl_fields');

function azl_fields($azexo_fields) {
    global $azl_fields;
    return array_merge($azexo_fields, $azl_fields);
}

add_filter('azexo_fields_post_types', 'azl_fields_post_types');

function azl_fields_post_types($azexo_fields_post_types) {
    global $azl_fields;
    $azexo_fields_post_types = array_merge($azexo_fields_post_types, array_combine(array_keys($azl_fields), array_fill(0, count(array_keys($azl_fields)), '')));
    return $azexo_fields_post_types;
}

add_filter('azexo_entry_field', 'azl_entry_field', 10, 2);

function azl_entry_field($output, $name) {
    global $post;
    wp_enqueue_script('azl');
    switch ($name) {
        case 'azl_edit_link':
            if ($post->post_author == get_current_user_id() || current_user_can('manage_options')) {
                return '<div class="azl-edit"><a href="' . esc_url(add_query_arg(array('azl' => 'edit', 'id' => $post->ID))) . '">' . esc_html__('Edit', 'azl') . '</a></div>';
            }
            break;
        case 'azl_delete_link':
            if ($post->post_author == get_current_user_id() || current_user_can('manage_options')) {
                return '<div class="azl-delete"><a href="' . esc_url(add_query_arg(array('azl' => 'delete', 'id' => $post->ID))) . '">' . esc_html__('Delete', 'azl') . '</a></div>';
            }
            break;
        case 'azl_claim_link':
            if ($post->post_author == 1) {
                $users = get_post_meta($post->ID, 'claim');
                return '<div class="azl-claim ' . (in_array(get_current_user_id(), $users) ? 'claimed' : '') . '"><a href="' . esc_url(add_query_arg(array('azl' => 'claim', 'id' => $post->ID))) . '">' . esc_html__('Claim', 'azl') . '</a></div>';
            }
            break;
        case 'azl_abuse_link':
            return '<div class="azl-abuse"><a href="' . esc_url(add_query_arg(array('azl' => 'abuse', 'id' => $post->ID))) . '">' . esc_html__('Report spam, abuse, or inappropriate content', 'azl') . '</a></div>';
            break;
        case 'azl_favorite_link':
            $users = get_post_meta($post->ID, 'favorite');
            if(in_array(get_current_user_id(), $users)) {
                return '<div class="azl-favorite remove"><a href="' . esc_url(add_query_arg(array('azl' => 'favorite', 'id' => $post->ID))) . '">' . esc_html__('Remove from favorites', 'azl') . '</a></div>';
            } else {
                return '<div class="azl-favorite add"><a href="' . esc_url(add_query_arg(array('azl' => 'favorite', 'id' => $post->ID))) . '">' . esc_html__('Add to favorites', 'azl') . '</a></div>';
            }            
            break;
    }
    return $output;
}

add_filter('azl_google_map_location', 'azl_google_map_location', 10, 2);

function azl_google_map_location($location, $location_post) {

    global $post;
    $original = $post;
    $post = $location_post;
    setup_postdata($location_post);

    $location = array_merge(array(
        'thumbnail' => azexo_entry_meta('google_map_product', 'thumbnail'),
        'extra' => azexo_entry_meta('google_map_product', 'extra'),
        'meta' => azexo_entry_meta('google_map_product', 'meta'),
        'footer' => azexo_entry_meta('google_map_product', 'footer'),
        'data' => azexo_entry_meta('google_map_product', 'data')
            ), $location);

    wp_reset_postdata();
    $post = $original;

    return $location;
}
