<?php

add_filter('azqf_open_render', 'azqf_open_render', 10, 2);

function azqf_open_render($output, $field) {

    $output = '<div class="open">';

    if (isset($field['label'])) {
        $output .= '<label>' . esc_html($field['label']) . '</label>';
    }

    $output .= '<div class="radius">';
    $id = 'on-' . rand(0, 99999999);
    $output .= '<input id="' . $id . '" type="checkbox" name="open" ' . ((isset($field['default']) && $field['default']) ? 'checked="checked' : '') . '">';
    $output .= '<label for="' . $id . '">';
    $output .= esc_attr__('Open now', 'azqf');
    $output .= '</label>';
    $output .= '</div>';


    $output .= '</div>';
    return $output;
}

add_action('azqf_open_process', 'azqf_open_process', 10, 2);

function azqf_open_process($query, $field) {
    $open = isset($_GET['open']) && 'on' == $_GET['open'];
    if ($open) {
        $meta_query = $query->get('meta_query');
        $meta_query[] = array(
            'key' => $field['meta_key'] . '-' . date('N') . 'hours',
            'value' => date('G')
        );
        $query->set('meta_query', $meta_query);
    }
}
