<?php

add_filter('azqf_search_text_render', 'azqf_search_text_render', 10, 2);

function azqf_search_text_render($output, $field) {
    $output = '<div class="s-wrapper">';
    if (isset($field['label'])) {
        $output .= '<label>' . esc_html($field['label']) . '</label>';
    }    
    $output .= '<input type="text" name="s" value="' . get_search_query() . '" placeholder="' . (isset($field['placeholder']) ? esc_attr($field['placeholder']) : '') . '" />';
    $output .= '</div>';
    return $output;
}
