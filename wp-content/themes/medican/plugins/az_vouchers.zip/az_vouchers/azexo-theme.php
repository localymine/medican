<?php

//global $azv_fields;
//
//$azv_fields = array(
//);
//
//add_filter('azexo_fields', 'azv_fields');
//
//function azv_fields($azexo_fields) {
//    global $azv_fields;
//    return array_merge($azexo_fields, $azv_fields);
//}
//
//add_filter('azexo_fields_post_types', 'azv_fields_post_types');
//
//function azv_fields_post_types($azexo_fields_post_types) {
//    global $azv_fields;
//    $azexo_fields_post_types = array_merge($azexo_fields_post_types, array_combine(array_keys($azv_fields), array_fill(0, count(array_keys($azv_fields)), 'product')));
//    return $azexo_fields_post_types;
//}
//
//add_filter('azexo_entry_field', 'azv_entry_field', 10, 2);
//
//function azv_entry_field($output, $name) {
//    if (class_exists('WooCommerce')) {
//        global $product;
//        switch ($name) {
//        }
//    }
//    return $output;
//}
