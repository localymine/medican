<center class="dashboard-buttons">
    <p>
        <a href="<?php print $shop_page; ?>" class="button your-store"><?php esc_html_e('View Your Store', 'wcvendors'); ?></a>
        <a href="<?php print $settings_page; ?>" class="button store-settings"><?php esc_html_e('Store Settings', 'wcvendors'); ?></a>
    </p>
</center>

<hr>