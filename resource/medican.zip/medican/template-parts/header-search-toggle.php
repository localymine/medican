<a href="#" class="trigger search" data-trigger-class="search-triggered" data-trigger-on="#masthead" data-trigger-off="#masthead"></a>

