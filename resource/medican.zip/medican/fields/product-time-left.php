<?php

/*
  Field Name: Product event time left
 */
?>
<?php

global $product;
$event_date_time = get_post_meta($product->id, 'event-date-time', true);
if ($event_date_time) {
    azexo_time_left($event_date_time);
}
?>