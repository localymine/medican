<?php
/*
  Template Name: Blog half image post
 */
?>

<?php 
$template_name = 'half_image_post';
include(locate_template('list.php')); 
?>
