<?php
/*
  Template Name: Blog background image post
 */
?>

<?php 
$template_name = 'bg_image_post';
include(locate_template('list.php')); 
?>
