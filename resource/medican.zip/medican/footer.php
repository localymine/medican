<?php ?>

</div><!-- #main -->

<footer id="colophon" class="site-footer clearfix">

    <?php get_sidebar('footer'); ?>

</footer><!-- #colophon -->

</div><!-- #page -->

<?php wp_footer(); ?>
</body>
</html>